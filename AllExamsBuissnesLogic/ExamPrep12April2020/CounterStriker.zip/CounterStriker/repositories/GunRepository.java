package CounterStriker.repositories;

import CounterStriker.common.ExceptionMessages;
import CounterStriker.models.guns.Gun;
import CounterStriker.models.guns.GunImpl;

import java.util.ArrayList;
import java.util.Collection;

public class GunRepository implements Repository<GunImpl>{
    private Collection<GunImpl> models;

    public GunRepository() {
        this.models = new ArrayList<>();
    }

    @Override
    public Collection<GunImpl> getModels() {
        return this.models;
    }

    @Override
    public void add(GunImpl model) {
        if (model==null){
            throw new NullPointerException(ExceptionMessages.INVALID_GUN_REPOSITORY);
        }
this.models.add(model);
    }

    @Override
    public boolean remove(GunImpl model) {
       return this.models.remove(model);
    }


    @Override
    public GunImpl findByName(String name) {
       /* for (GunImpl gun :this.models) {
            if (name.equals(gun.getName())){
                return gun;
            }
        }

            return null;*/
        return this.models.stream().filter(n-> n.getName().equals(name)).findFirst().orElse(null);
    }
}
