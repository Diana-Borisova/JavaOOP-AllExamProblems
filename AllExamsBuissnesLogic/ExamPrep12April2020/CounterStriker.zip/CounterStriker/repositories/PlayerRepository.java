package CounterStriker.repositories;

import CounterStriker.common.ExceptionMessages;
import CounterStriker.models.players.PlayerImpl;

import java.util.ArrayList;
import java.util.Collection;

public class PlayerRepository implements Repository<PlayerImpl> {
    private Collection<PlayerImpl> models;

    public PlayerRepository() {
        this.models = new ArrayList<>();
    }

    @Override
    public Collection<PlayerImpl> getModels() {
        return this.models;
    }

    @Override
    public void add(PlayerImpl model) {
        if (model==null){
            throw new NullPointerException(ExceptionMessages.INVALID_PLAYER_REPOSITORY);
        }
this.models.add(model);
    }

    @Override
    public boolean remove(PlayerImpl model) {
        return  this.models.remove(model);
    }

    @Override
    public PlayerImpl findByName(String name) {
        return this.models.stream().filter(a-> a.equals(this.findByName(name))).findFirst().orElse(null);
    }
}
