package catHouse.core;

import catHouse.common.ConstantMessages;
import catHouse.common.ExceptionMessages;
import catHouse.entities.cat.Cat;
import catHouse.entities.cat.LonghairCat;
import catHouse.entities.cat.ShorthairCat;
import catHouse.entities.houses.House;
import catHouse.entities.houses.LongHouse;
import catHouse.entities.houses.ShortHouse;
import catHouse.entities.toys.Ball;
import catHouse.entities.toys.Mouse;
import catHouse.entities.toys.Toy;
import catHouse.repositories.Repository;
import catHouse.repositories.ToyRepository;

import java.util.*;

public class ControllerImpl implements Controller {
    private ToyRepository toyRepository;
    private List<House>houses;
    private Map<Toy,House> toyHouseMap;
    private Map<Cat,House>catHouseMap;

    public ControllerImpl() {
this.toyRepository = new ToyRepository();
this.houses = new ArrayList<>();
this.toyHouseMap= new LinkedHashMap<>();
this.catHouseMap = new LinkedHashMap<>();
    }

    @Override
    public String addHouse(String type, String name) {
        House house;
        if (type.equals("ShortHouse")){
            house = new ShortHouse(name);
            houses.add(house);
        }else if (type.equals("LongHouse")){
            house = new LongHouse(name);
            houses.add(house);
        }else {
            throw new NullPointerException(ExceptionMessages.INVALID_HOUSE_TYPE);
        }
        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_HOUSE_TYPE, type);
    }

    @Override
    public String buyToy(String type) {
        Toy toy;
        if (type.equals("Mouse")){
            toy = new Mouse();
            toyRepository.getToys().add(toy);
        }else if (type.equals("Ball")){
            toy = new Ball();
            toyRepository.getToys().add(toy);
        }else {
            throw new IllegalArgumentException(ExceptionMessages.INVALID_TOY_TYPE);
        }
        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_TOY_TYPE, type);
    }

    @Override
    public String toyForHouse(String houseName, String toyType) {
        if (this.toyRepository.getToys().size() == 0) {
            if (toyType.equals("Ball") || toyType.equals("Mouse")) {
                for (int i = 0; i < this.houses.size(); i++) {
                    if (this.houses.get(i).getName().equals(houseName)) {
                        toyHouseMap.put(this.toyRepository.findFirst(toyType), this.houses.get(i));
                        Toy toy = this.toyRepository.findFirst(toyType);
                        this.toyRepository.removeToy(toy);
                    }
                }
            }
            String em = String.format(ConstantMessages.SUCCESSFULLY_ADDED_HOUSE_TYPE, toyType, houseName);
            return String.format(em);
        } else {
            String em = String.format(ExceptionMessages.NO_TOY_FOUND, toyType);
            throw new IllegalArgumentException(em);
        }
    }

    @Override
    public String addCat(String houseName, String catType, String catName, String catBreed, double price) {
        Cat cat;

        if (!catType.equals("ShorthairCat")&& !catType.equals("LonghairCat")){
            throw new IllegalArgumentException(ExceptionMessages.INVALID_CAT_TYPE);
        }
        if (houseName.equals("ShortHouse") && catType.equals("ShorthairCat")){
            cat = new ShorthairCat(catName,catBreed,price);
            for (House house :this.houses) {
                if (houseName.equals(house.getName())){
                    catHouseMap.put(cat,house);
                    return String.format(ConstantMessages.SUCCESSFULLY_ADDED_CAT_IN_HOUSE, cat,house);
                }
            }

        } else if (houseName.equals("LongHouse") && catType.equals("LonghairCat")){
            cat = new LonghairCat(catName,catBreed,price);
            for (House house :this.houses) {
                if (houseName.equals(house.getName())){
                    catHouseMap.put(cat,house);
                    return String.format(ConstantMessages.SUCCESSFULLY_ADDED_CAT_IN_HOUSE, cat,house);
                }
            }
        }
            return String.format(ConstantMessages.UNSUITABLE_HOUSE);
    }

    @Override
    public String feedingCat(String houseName) {
        int catsCount = 0;
        for (House house :this.houses) {
            if (houseName.equals(house.getName())){
              catsCount =   catHouseMap.get(house).getCats().size();
            }
        }
        return String.format(ConstantMessages.FEEDING_CAT,catsCount);
    }

    @Override
    public String sumOfAll(String houseName) {
       double catSum = 0;
        for (Cat cat : catHouseMap.get(houseName).getCats()) {
           catSum += cat.getPrice();
        }
       double toysSum = 0;
        for (Toy toy : toyHouseMap.get(houseName).getToys()) {
            toysSum+= toy.getPrice();
        }
        double totalSum = catSum+ toysSum;

        return String.format(ConstantMessages.VALUE_HOUSE, houseName, totalSum);
    }

    @Override
    public String getStatistics() {
        StringBuilder sb = new StringBuilder();
       catHouseMap.forEach((cat, house)-> house.getCats().forEach(cat1 -> {
           if (cat1 != null) {
               sb.append(house.getName() + " " + cat1 +" ");
           } else {
               sb.append(" none");
           }
       }));
       toyHouseMap.forEach((toy,house)-> house.getToys().forEach(toy1 -> {
           if (toy1 != null){
               sb.append(house.getName() + " " + toy1+ " ");
           } else {
               sb.append(" none");
           }
       }));


        return sb.toString().trim();
    }
}
