package catHouse.repositories;

import catHouse.entities.toys.Toy;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class ToyRepository implements Repository{
    private List< Toy> toys;

    public ToyRepository() {
        this.toys = new ArrayList<>();
    }

    @Override
    public void buyToy(Toy toy) {
this.toys.add(toy);
    }

    @Override
    public boolean removeToy(Toy toy) {
        if (this.toys.contains(toy)){
            this.toys.remove(toy);
            return true;
        }
        return false;
    }

    @Override
    public Toy findFirst(String type) {
        for (int i = 0; i < toys.size(); i++) {
            if (toys.get(i).equals(type)){
                return toys.get(i);

            }
        }      return null;
    }

    public List<Toy> getToys() {
        return toys;
    }
}
