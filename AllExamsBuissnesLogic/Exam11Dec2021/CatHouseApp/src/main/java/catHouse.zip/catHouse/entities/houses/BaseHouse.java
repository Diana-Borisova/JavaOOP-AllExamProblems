package catHouse.entities.houses;

import catHouse.common.ConstantMessages;
import catHouse.common.ExceptionMessages;
import catHouse.entities.cat.Cat;
import catHouse.entities.toys.Toy;

import java.util.*;

public abstract class BaseHouse implements House{
    private String name;
    private int capacity;
    private List<Toy> toys;
    private List<Cat> cats;
    private ShortHouse shortHouse;
    private LongHouse longHouse;


    public BaseHouse(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.toys = new ArrayList<>();
        this.cats = new ArrayList<>();

    }

    @Override
    public int sumSoftness() {
        int sumSoftness=0;
        for (Toy toy :this.toys) {
          sumSoftness +=  toy.getSoftness();
        }
        return sumSoftness;
    }

    @Override
    public void addCat(Cat cat) {
if (this.cats.size()<this.capacity){
    if (this.name.equals("ShortHouse") && cat.getName().equals("ShorthouseCat")){
        cats.add(cat);
    } else if (this.name.equals("LongHouse") && cat.getName().equals("LonghouseCat")){
        cats.add(cat);
    }

} else {
    throw new IllegalStateException(ConstantMessages.NOT_ENOUGH_CAPACITY_FOR_CAT);
}
    }

    @Override
    public void removeCat(Cat cat) {
if (this.cats.contains(cat)){
    this.cats.remove(cat);
}
    }

    @Override
    public void buyToy(Toy toy) {
    this.toys.add(toy);
    }

    @Override
    public void feeding() {

    }

    @Override
    public String getStatistics() {
      StringBuilder sb = new StringBuilder();
      sb.append(this.name+ " ").append(shortHouse.getName()).append(System.lineSeparator());
        sb.append("Cats: ");
      if (cats.size() >0) {

          for (Cat cat : cats) {
              sb.append(cat.getName() + " ");
          }
      } else {
          sb.append("none");
      }
      sb.append(System.lineSeparator());
      sb.append("Toys: ").append(toys.size()).append(" ").append("Softness: ").append(this.sumSoftness());
      return sb.toString().trim();
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void setName(String name) {
        if (name==null || name.trim().isEmpty()){
            throw new NullPointerException(ExceptionMessages.HOUSE_NAME_CANNOT_BE_NULL_OR_EMPTY);
        }
        this.name=name;
    }

    @Override
    public List<Cat> getCats() {
        return this.cats;
    }

    @Override
    public List<Toy> getToys() {
        return this.toys;
    }
}
