package onlineShop.models.products;


import onlineShop.common.constants.OutputMessages;
import onlineShop.models.products.components.Component;

public abstract class BaseComponent extends BaseProduct implements Component {
    private int generation;

    public BaseComponent(int id, String manufacturer, String model, double price, double overallPerformance, int generation) {
        super(id, manufacturer, model, price, overallPerformance);
        this.generation = generation;
    }

    @Override
    public String toString() {
      StringBuilder sb = new StringBuilder();
        sb.append(String.format("  Overall Performance: %.2f. ", super.getOverallPerformance()))
            .append(String.format("Price: %.2f - %s: %s %s ", super.getPrice(), super.getClass().getSimpleName(), super.getManufacturer(),
                        super.getModel()))
            .append(String.format("(Id: %d) ", super.getId()))
                .append(String.format(OutputMessages.COMPONENT_TO_STRING, this.generation)).append(System.lineSeparator());
               return sb.toString().trim();
}

    @Override
    public int getGeneration() {
        return this.generation;
    }
}