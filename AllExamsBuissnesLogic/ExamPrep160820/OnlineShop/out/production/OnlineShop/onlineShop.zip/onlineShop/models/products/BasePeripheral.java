package onlineShop.models.products;

import onlineShop.common.constants.OutputMessages;
import onlineShop.models.products.peripherals.Peripheral;

public abstract class BasePeripheral extends BaseProduct implements Peripheral {
    private String connectionType;

    public BasePeripheral(int id, String manufacturer, String model, double price, double overallPerformance, String connectionType) {
        super(id, manufacturer, model, price, overallPerformance);
        this.connectionType = connectionType;
    }

    @Override
    public int getId() {
        return super.getId();
    }

    @Override
    public String getManufacturer() {
        return super.getManufacturer();
    }

    @Override
    public String getModel() {
        return super.getModel();
    }

    @Override
    public double getPrice() {
        return super.getPrice();
    }

    @Override
    public double getOverallPerformance() {
        return super.getOverallPerformance();
    }

    @Override
    public String toString() {

        return String.format(OutputMessages.PRODUCT_TO_STRING + OutputMessages.PERIPHERAL_TO_STRING,
                super.getOverallPerformance(),super.getPrice(), super.getModel().getClass().getSimpleName(),
                super.getManufacturer(), super.getModel(), super.getId(), this.connectionType);
    }

    @Override
    public String getConnectionType() {
        return this.getConnectionType();
    }
}
