package glacialExpedition.repositories;

import glacialExpedition.models.explorers.BaseExplorer;
import glacialExpedition.models.explorers.Explorer;

import java.util.*;

public class ExplorerRepository implements Repository<Explorer> {


    Map<String, Explorer> explorers;

    public ExplorerRepository() {
        explorers = new LinkedHashMap<>();
    }

    @Override
    public Collection<Explorer> getCollection() {
        return Collections.unmodifiableCollection(explorers.values());
    }

    @Override
    public void add(Explorer explorer) {
        explorers.put(explorer.getName(), explorer);
    }

    @Override
    public boolean remove(Explorer explorer) {
        return explorers.remove(explorer.getName()) != null;

    }

    @Override
    public Explorer byName(String name) {
        return explorers.get(name);
    }


}