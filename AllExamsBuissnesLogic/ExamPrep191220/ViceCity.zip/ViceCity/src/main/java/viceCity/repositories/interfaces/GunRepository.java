package viceCity.repositories.interfaces;

import viceCity.models.guns.Gun;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class GunRepository implements Repository<Gun>{
    private List<Gun> models;

    public GunRepository() {
        this.models = new ArrayList<>();
    }

    @Override
    public Collection<Gun> getModels() {
        return Collections.unmodifiableCollection(this.models);
    }

    @Override
    public void add(Gun model) {
        if (!this.models.contains(model)){
            this.models.add(model);
        }

    }

    @Override
    public boolean remove(Gun model) {
        if (this.models.contains(model)){
        return true;
        }
        return false;
    }

    @Override
    public Gun find(String name) {
        int index = 0;
        for (int i = 0; i <this.models.size() ; i++) {
            if (name.equals(this.models.get(i).getName())){
                index= i;
            }
        }
        return this.models.get(index);
    }
}
